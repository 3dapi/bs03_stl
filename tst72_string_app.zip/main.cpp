
#pragma warning( disable : 4786)

#include <string>
#include <vector>

#include <stdio.h>


typedef std::vector<std::string >	lsStr;
typedef lsStr::iterator			itStr;


void main()
{
	std::string	st = "123456789012345678901234567890";
	lsStr	vStr;
	
	vStr.push_back(st);
	
	printf("String: %s \n", vStr[0].c_str());
	
	printf("Size: %d \n", vStr[0].size());
	printf("Find: %d \n", vStr[0].find("456"));
	printf("RFind: %d \n", vStr[0].rfind("456"));
	
	printf("Compare: %d \n", vStr[0].compare(st));
	printf("Compare: %d \n", vStr[0].compare("123"));
	printf("Compare: %d \n", vStr[0].compare("456"));

	char sValue[] = "ABCDEFGHIJKLMN";

//	printf("Value: %s \n", sValue);
//	printf("Begin: %d \n", *vStr[0].begin());

	vStr[0].insert(0, sValue, sizeof(sValue)-1);
//	printf("Insert: %s \n", vStr[0].c_str());

	vStr[0].insert(vStr[0].size(), sValue, 7);
//	printf("Insert: %s \n", vStr[0].c_str());

	vStr[0].insert(10, sValue, 5);
	vStr[0].insert(30, sValue, 5);
//	printf("Insert: %s \n", vStr[0].c_str());
//
//	printf("Begin: %c \n", *vStr[0].begin());
//	printf("End-3: %c \n", *(vStr[0].end()-3));

	int fd =vStr[0].find( *(sValue+2), 0);
	int	rd = vStr[0].rfind( *sValue);

	printf("String: %s \n", (sValue+2));

	printf("String: %s \n", vStr[0].c_str());
	printf("Size: %d \n", vStr[0].size());

	printf("Find: %d '%c'\n", fd, *(vStr[0].begin() + fd));
	printf("rFind: %d '%c'\n", rd, *(vStr[0].begin() + rd));
}
