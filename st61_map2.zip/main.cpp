
#pragma warning( disable : 4786)

#include <map>
#include <string>
#include <functional>

#include <stdio.h>


struct StIdx
{
	int nID;
	int iValue;
	
	StIdx(){}
	
	StIdx(int _id, int _value)
	{
		nID =_id;
		iValue= _value;
	}
};


template<class T>
struct Comp
{
	bool operator()(const T& t1, const T& t2) const
	{
		return (t1.nID < t2.nID);
	}
};

typedef	std::map<std::string, int>		mpLst2;
typedef	mpLst2::iterator			itLst2;



void main()
{
	mpLst2		mpTst;

	mpTst.insert( mpLst2::value_type("Hello", 1000));
	mpTst.insert( mpLst2::value_type("World", 2300));
	mpTst.insert( mpLst2::value_type("Hi", 1500));
	mpTst.insert( mpLst2::value_type("Welcome", 1000));

	printf("%d\n", mpTst["Welcome"]);
	printf("%d\n", mpTst["Hi"]);
	printf("%d\n", mpTst["World"]);
	printf("%d\n", mpTst["Hello"]);

	char	s[] ="Hello";
	printf("%d\n", mpTst[s]);
}