

#pragma warning( disable : 4786)

#include <hash_set>
#include <stdio.h>

using namespace stdext;


struct MyStruct
{
	int	wId;

	MyStruct(){}
	MyStruct(int c) : wId(c){}

	operator size_t() const {	return sizeof(MyStruct);	}
};

template<class T>
struct Tgreater
{
	bool operator()(const T& t1,const T& t2) const	{ return t1.wId < t2.wId; }
};


typedef hash_set< MyStruct									\
				, hash_compare<MyStruct, Tgreater<MyStruct> >
				>	stInt;

typedef stInt::iterator	itInt;





void main()
{
	stInt lsInt;

	for(int i=0; i<100; ++i)
	{
		lsInt.insert(MyStruct( rand()%8));
	}


	for(itInt it= lsInt.begin(); it !=lsInt.end(); )
	{
		MyStruct infc = (*it);
		printf("%d\n", infc.wId);
		++it;
	}
}