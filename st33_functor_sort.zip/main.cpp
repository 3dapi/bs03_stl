

#include <algorithm>

#include <stdio.h>
#include <malloc.h>


// �� ����� ���������� ��� ���ϴ� ���� �����ϴ�.
//struct TGameData
//{
//	int nIndex;	
//
//	bool operator()(const TGameData& v1, const TGameData& v2)
//	{
//		return v1.nIndex > v2.nIndex;
//	}
//};
//
//
//void main()
//{
//	int		i;
//	const int		iN=200;
//	
//	TGameData*	pN = (TGameData*) malloc( iN * sizeof(TGameData));
//	
//	for(i=0; i<iN; ++i)
//	{
//		pN[i].nIndex = rand()%iN;
//	}
//	
//
//	std::sort(pN, pN+iN, TGameData());
//	
//	for(i=0; i< iN; ++i)
//		printf("%3d: %4d\n", i, pN[i].nIndex);
//
//
//	free(pN);
//}


struct TGameData
{
	int nIndex;	
};


struct Greater
{
	bool operator()(const TGameData& v1, const TGameData& v2)
	{
		return v1.nIndex > v2.nIndex;
	}
};


void main()
{
	int		i;
	const int		iN=200;
	
	TGameData*	pN = (TGameData*) malloc( iN * sizeof(TGameData));
	
	for(i=0; i<iN; ++i)
	{
		pN[i].nIndex = rand()%iN;
	}
	

	std::sort(pN, pN+iN, Greater());
	
	for(i=0; i< iN; ++i)
		printf("%3d: %4d\n", i, pN[i].nIndex);


	free(pN);
}
