
#include <vector>
#include <list>
#include <algorithm>

#include <stdio.h>

void Find_Example()
{
	std::list<int> vLst;
	std::list<int>::iterator Dst;

	vLst.push_back( 54 );
	vLst.push_back( 62 );
	vLst.push_back( 23 );
	vLst.push_back( 33 );
	vLst.push_back( 63 );
	vLst.push_back( 46 );
	vLst.push_back( 71 );


	for(std::list<int>::iterator it = vLst.begin(); it != vLst.end(); ++it)
		printf("%4d ", *it);
	
	printf("\n");




	Dst = std::find( vLst.begin(), vLst.end(), 63);
	if  ( Dst == vLst.end() )
	{
		printf("����� ã�� �� �����ϴ�.\n");
	}
	else
	{
		printf("ã�� ��:%d\n", *Dst);
	}

}



bool Functor(const int& v)
{
	return v > 16;
}


template<class T>
struct Greater
{
	T t;
	Greater(){}
	bool operator() (const T& v)
	{
		return v > t;
	}
};



void Find_If_Example()
{
	using namespace std;

	std::list<int> vLst;
	std::list<int>::iterator Dst;

	vLst.push_back( 5 );
	vLst.push_back( 10 );
	vLst.push_back( 15 );
	vLst.push_back( 20 );
	vLst.push_back( 14 );
	vLst.push_back( 10 );
	vLst.push_back( 34 );
	vLst.push_back( 13 );
	vLst.push_back( 56 );

	
	for(std::list<int>::iterator it = vLst.begin(); it != vLst.end(); ++it)
		printf("%4d ", *it);

	printf("\n");


//	Dst = find_if( vLst.begin(), vLst.end(), &Functor );

	Greater<int> G;
	G.t = 20;
	Dst = find_if( vLst.begin(), vLst.end(), G );
	if  ( Dst == vLst.end() )
	{
		printf("����� ã�� �� �����ϴ�.\n");
	}
	else
	{
		printf("ã�� ��:%d\n", *Dst);
	}
}




template <class T>
class MultValue
{
private:
	T f;
public:
	MultValue ( const T& v) : f (v){}

	void operator() (T& v) const
	{
		v *= f;
	}
};


class Average
{
public:
	long n;		// The number of elements
	long s;		// The sum of the elements
public:
	Average() : n(0) , s(0)
	{
	}

	void operator()	 (int v)
	{
		n++;
		s += v;
	}

	operator double()
	{
		return  double(s) / double(n);
	}
};

void For_Each_Example()
{
	std::vector<int> vLst;
	std::vector<int>::iterator it;

	for(int i = 1 ; i <= 5 ; i++ )
	{
		vLst.push_back(  i );
	}


	printf("Before for_each():\n");
	for(it = vLst.begin(); it != vLst.end(); ++it)
		printf("%4d ", *it);

	std::for_each ( vLst.begin () , vLst.end () , MultValue<int> ( -2 ) );


	printf("After for_each(MultValue<int> (-2)):\n");
	for(it = vLst.begin(); it != vLst.end(); ++it)
		printf("%4d ", *it);

	printf("\n");


	for_each (vLst.begin () , vLst.end () , MultValue<int> (5) );

	printf("Another for_each(MultValue<int> (5)):\n");
	for(it = vLst.begin(); it != vLst.end(); ++it)
		printf("%4d ", *it);

	printf("\n");


	//Average	av;
	//Average& t = for_each (vLst.begin () , vLst.end () , av );
	//printf("Another for_each(Average()):\n");
	//printf("%ld\n", t.s);

	double r = for_each (vLst.begin () , vLst.end () , Average());
	printf("Another for_each(Average()):\n");
	printf("%lf\n", r);
}

void main()
{
	::For_Each_Example();
}