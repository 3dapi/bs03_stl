
#include <vector>
#include <stdio.h>

using namespace std;


struct _T
{
	int c;
	int d;

	_T() : c(0), d(0){}
	_T(int t) :c(0), d(t){}

	void* GetThis()
	{
		return (this);
	}

	_T(const _T& r)
	{
		this->c = r.c;
		this->d = r.d;
	}

	_T(const _T* r)
	{
		this->c = r->c;
		this->d = r->d;
	}

	void* operator=(const _T& r)
	{
		return this;
	}
};

void main()
{
	unsigned int	i = 0;
	vector<_T >		lsInt;

	for(i=1; i<11; ++i)
	{
		lsInt.push_back(_T(i));
	}




	// using Operator[]
	for(i=0; i<lsInt.size(); ++i)
	{
		_T*	p = &lsInt[i];

//		printf("%d\n", p->d);
	}


	// using Iterator
	vector<_T >::iterator	_F = lsInt.begin();
	vector<_T >::iterator	_L = lsInt.end();

	for( ; _F !=_L; ++_F)
	{
		_T* p = (_T*)(_F->GetThis());
//		printf("%d\n", p->d);
	}

	_F = lsInt.begin();
	_L = lsInt.end();

	
	_T*		p = NULL;

	for( ; _F !=_L; ++_F)
	{
		vector<_T >::reference _t= *_F;
		p = (_T*)(&_t);

		//__asm
		//{
		//	mov         eax, _F
		//	mov         dword ptr [p],eax
		//}


		printf("%d\n", p->d);
	}


	//void*	p = (void*)&lsInt;
	//vector<_T >*	t=NULL;

	//t = (vector<_T >*)p;

	//t->begin();
}