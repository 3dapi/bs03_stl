
#include <string>
#include <vector>
#include <algorithm>

#include <stdio.h>


struct UsrInfo
{
	std::string	sName;
	int			iAge;

	UsrInfo(const std::string& str, const int& age) : sName(str), iAge(age){}
};



struct LessName
{
	bool operator() (const UsrInfo& t1, const UsrInfo& t2)
	{
		return t1.sName < t2.sName;
	}
};

struct LessAge
{
	bool operator() (const UsrInfo& t1, const UsrInfo& t2)
	{
		return t1.iAge < t2.iAge;
	}
};

typedef std::vector<UsrInfo>	lsUsrInfo;



void StableSort()
{
	lsUsrInfo	v;
	
	v.push_back( UsrInfo("ȫ�浿", 11));
	v.push_back( UsrInfo("ȫ�浿", 16));
	v.push_back( UsrInfo("�蹫��", 13));
	v.push_back( UsrInfo("���켺", 10));
	v.push_back( UsrInfo("ȫ�浿", 14));
	v.push_back( UsrInfo("�蹫��", 17));
	v.push_back( UsrInfo("ȫ�浿", 12));
	v.push_back( UsrInfo("���켺", 15));


	std::stable_sort(v.begin(), v.end(), LessName());
	std::stable_sort(v.begin(), v.end(), LessAge());
	


	for(int i=0; i<v.size(); ++i)
	{
		printf("%s: %d\n", v[i].sName.c_str(), v[i].iAge);
	}
}





void main()
{
	StableSort();
}