

#include <stdio.h>


template<class T>
struct DLinkedList
{
	struct Node
	{
		T		_Data;

		Node*	_Prev;
		Node*	_Next;

		Node()
		{
			_Prev = NULL;
			_Next = NULL;
		}

		Node(T& _data)
		{
			_Data = _data;
			_Prev = NULL;
			_Next = NULL;
		}

		void insert(Node* r)
		{
			Node* p = this->_Next;

			this->_Next = r;
			r->_Prev = this;

			r->_Next = p;

			if(p)
				p->_Prev = r;
		}

		Node* Next()
		{
			return this->_Next;
		}

		Node* Prev()
		{
			return this->_Prev;
		}
	};


	Node*	_Begin;
	Node*	_End;


	DLinkedList()
	{
		_Begin	= NULL;
		_End	= _Begin;
	}

	Node* begin()	{		return _Begin;	}
	Node* end()		{		return _End;	}


	Node* Alloc(T& r)
	{
		Node* p = new  Node(r);
		return p;
	}


	void push_back(T r)
	{
		if(NULL == _Begin)
		{
			_Begin = new Node(r);
			_End   = _Begin;
			return ;
		}
		
		Node* t = end();
		Node* p = Alloc(r);

		t->insert(p);
		_End = p;
	}

	void push_back(T& r)
	{
		Node* t = end();

		Node* p = Alloc(r);
		t->insert(p);
	}


	void clear()
	{
		Node* p = _Begin;

		while(p)
		{
			Node* t = p->Next();
			delete p;
			p = t;
		}
	}

	
	struct iterator
	{
		Node*	t;
		iterator()
		{
		}
	
		iterator(Node& _t): t(_t)
		{
		}

		iterator(Node* _t): t(_t)
		{
		}

		iterator& operator++()
		{
			t = t->Next();
			return (*this);
		}

		iterator& operator--()
		{
			t = t->Prev();
			return (*this);
		}

		iterator& operator =(Node* r)
		{
			t = r;
		}

		operator void*()
		{
			return t;
		}

		T* operator->() const
		{
			return &(t->_Data);
		}
	};

};


struct User
{
	int d;
	int c;

	User(): c(0){	d = 0;	}
	User(int k) : c(k)	{		d = 0;	}
};

void main()
{
	int iTot =10;

	DLinkedList<User> Link;

	for(int i=0;i<iTot;i++)
		Link.push_back( i * 100);


	DLinkedList<User>::iterator _F = Link.begin();
	DLinkedList<User>::iterator _L = Link.end();


	for(; _L != _F; --_L)
	{
		printf("%d ", _L->c);
	}

	Link.clear();

	printf("\n\n");
}