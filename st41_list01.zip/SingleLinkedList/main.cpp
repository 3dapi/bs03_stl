

#include <stdio.h>


template<class T>
struct LinkedList
{
	struct Node
	{
		T		_Data;
		Node*	_Next;

		Node()
		{
			_Next = NULL;
		}

		Node(T& _data)
		{
			_Data = _data;
			_Next = NULL;
		}

		void insert(Node* r)
		{
			Node* p = this->_Next;
			this->_Next = r;
			r->_Next = p;
		}

		Node* Next()
		{
			return this->_Next;
		}
	};


	Node*	_Begin;
	Node*	_End;


	LinkedList()
	{
		_Begin	= NULL;
		_End	= _Begin;
	}

	Node* begin()	{		return _Begin;	}
	Node* end()		{		return _End;	}


	Node* Alloc(T& r)
	{
		Node* p = new  Node(r);
		return p;
	}


	void push_back(T r)
	{
		if(NULL == _Begin)
		{
			_Begin = new Node(r);
			_End   = _Begin;
			return ;
		}
		
		Node* t = end();
		Node* p = Alloc(r);

		t->insert(p);
		_End = p;
	}

	void push_back(T& r)
	{
		Node* t = end();

		Node* p = Alloc(r);
		t->insert(p);
	}


	void clear()
	{
		Node* p = _Begin;

		while(p)
		{
			Node* t = p->Next();
			delete p;
			p = t;
		}
	}

	
	struct iterator
	{
		Node*	t;
		iterator()
		{
		}
	
		iterator(Node& _t): t(_t)
		{
		}

		iterator(Node* _t): t(_t)
		{
		}

		iterator& operator++()
		{
			t = t->Next();
			return (*this);
		}

		iterator& operator =(Node* r)
		{
			t = r;
		}

		operator void*()
		{
			return t;
		}

		T* operator->() const
		{
			return &(t->_Data);
		}
	};

};


struct User
{
	int d;
	int c;

	User(): c(0){	d = 0;	}
	User(int k) : c(k)	{		d = 0;	}
};

void main()
{
	int iTot =10;

	LinkedList<User> Link;

	for(int i=0;i<iTot;i++)
		Link.push_back( i * 100);


	LinkedList<User>::iterator _F = Link.begin();
	LinkedList<User>::iterator _L = Link.end();


	for(; _F != _L; ++_F)
	{
		printf("%d ", _F->c);
	}

	Link.clear();

	printf("\n\n");
}