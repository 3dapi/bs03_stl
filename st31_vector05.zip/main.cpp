

#include <vector>
#include <stdio.h>


struct GameData
{
	int nIdx;
	int data;
	
	GameData(int _nIdx, int _data)
	{
		nIdx= _nIdx;
		data = _data;
	}
};

void main()
{
	int i;
	
	std::vector<GameData* >	pvData;
	
	
	for(i=0; i< 10; ++i)
		pvData.push_back( new GameData(i, i*100) );

	
	int iSize= pvData.size();
	for(i=0; i<iSize; ++i)
	{
		GameData** p = &pvData[i];
		printf("%d  %d\n", (*p)->nIdx, (*p)->data);

		// Iterator ĳ������ vc6.0 ���Ͽ����� ��밡��
		GameData** t = pvData.begin() + i;
		printf("%d  %d\n", (*t)->nIdx, (*t)->data);
	}


	for(i=0; i<iSize; ++i)
		delete (pvData[i]);

	pvData.clear();
}

