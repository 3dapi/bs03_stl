
#pragma warning( disable : 4786)

#include <map>
#include <string>

#include <stdio.h>


struct StIdx
{
	int nID;
	int iValue;
	
	StIdx(){}
	StIdx(int _id, int _value)
	{
		nID =_id;
		iValue= _value;
	}
};


template<class T>
struct Comp
{
	bool operator()(const T& t1, const T& t2) const
	{
		return (t1.nID < t2.nID);
	}
};

typedef std::map<StIdx, std::string,Comp<StIdx> > mpLst;
typedef mpLst::iterator							itLst;



void main()
{
	mpLst	theMap;
	itLst	it;
	
	StIdx st = StIdx( 300,  3000);
	
	theMap.insert(	mpLst::value_type( st, "2nd"));
	theMap.insert(	mpLst::value_type( StIdx( 600,  6000), "2nd"));
	theMap.insert(	mpLst::value_type( StIdx( 400,  4000), "3rd"));
	theMap.insert(	mpLst::value_type( StIdx( 100,  1000), "3rd"));
	theMap.insert(	mpLst::value_type( StIdx( 200,  2000), "1st"));

	// pair�� �̿��ص� ����.
	std::pair<StIdx, std::string> NewItem( StIdx( 500,  5000), "1stt");
	theMap.insert(NewItem); 

	
	theMap.insert(	mpLst::value_type( StIdx( 700,  7000), "2nd"));

	

	it = theMap.find(StIdx( 10, 100));

	if(it != theMap.end())
	{
		printf("%s\n", (*it).second.c_str());
		printf("%d\n", (*it).first.nID);
		printf("%d\n", (*it).first.iValue);
	}

	for(it = theMap.begin(); it != theMap.end(); ++it)
	{
		printf("%d	", (*it).first.nID);
		printf("%d	", (*it).first.iValue);
		printf("%s\n", (*it).second.c_str());
	}
}