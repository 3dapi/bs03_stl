

#include <algorithm>

#include <stdio.h>
#include <malloc.h>



struct TGameData
{
	int nIndex;	
};


template<class T>
struct Greater
{
	bool operator()(T& v1, T& v2)
	{
		return v1.nIndex > v2.nIndex;
	}
};


template<class T>
struct Less
{
	bool operator()(T& v1, T& v2)
	{
		return v1.nIndex < v2.nIndex;
	}
};



void main()
{
	int		i;
	const int		iN=200;
	
	TGameData*	pN = (TGameData*) malloc( iN * sizeof(TGameData));
	
	for(i=0; i<iN; ++i)
	{
		pN[i].nIndex = rand()%iN;
	}
	

	std::sort(pN, pN+iN, Greater<TGameData>());
	
	for(i=0; i< iN; ++i)
		printf("%3d: %4d\n", i, pN[i].nIndex);


	free(pN);
}
