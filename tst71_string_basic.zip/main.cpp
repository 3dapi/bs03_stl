

#pragma warning( disable : 4786)

#include <string>

#include <stdio.h>



void main()
{
	char	str1[128]="Hello world 1234567890";
	std::string str2;

	str2 =str1;
	
	str2.erase();

	str2 =str1;

	printf("%s\n", str2.c_str());
	printf("%s\n", str1);
	printf("%d\n", strlen(str1));
	printf("%d\n", str2.length());
}
