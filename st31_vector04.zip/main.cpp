

#include <vector>
#include <stdio.h>


struct GameData
{
	int nIdx;
	int data;
	
	GameData(int _nIdx, int _data)
	{
		nIdx= _nIdx;
		data = _data;
	}
};

void main()
{
	int i;
	
	std::vector<GameData* >	pvData;
	
	
	for(i=0; i< 10; ++i)
		pvData.push_back( new GameData(i, i*100) );

	
	std::vector< GameData* >::iterator	_F = pvData.begin();
	std::vector< GameData* >::iterator	_L = pvData.end();
	
	for(; _F != _L; ++_F)
	{
		printf("%d  %d\n", (*_F)->nIdx, (*_F)->data);
	}

		
	_F = pvData.begin();
	
	for(; _F != _L; ++_F)
		delete (*_F);

	pvData.clear();
}

