
#include <vector>
#include <stdio.h>


void main()
{
	int i;
	int	iReserve= 4;

	std::vector< int >	vInt;
	
	vInt.reserve(iReserve);

	printf("Container Size: %d\n", vInt.size());
	printf("Container Capacity: %d\n", vInt.capacity());
	printf("------------------------------------------\n");
	
	for(i=0; i< 17; ++i)
		vInt.push_back(i);
	
	printf("Container Size: %d\n", vInt.size());
	printf("Container Capacity: %d\n", vInt.capacity());

	if(!vInt.empty())
	{
		for(i=0; i< vInt.size(); ++i)
			printf("%d\n", vInt[i]);
	}
	
	vInt.clear();
}