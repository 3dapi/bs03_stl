
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>


struct TGameData
{
	int nIndex;

	static int Greater( const TGameData* v1, const TGameData* v2)
	{
		return Less(v1, v2) * (-1);
	}

	static int Less( const TGameData* v1, const TGameData* v2)
	{
		if( v1->nIndex < v2->nIndex)
			return -1;

		else if( v1->nIndex == v2->nIndex)
			return 0;

		else
			return 1;
	}
};


void main()
{
	int		i;
	int		iN=200;
	
	TGameData*	pN = (TGameData*) malloc( iN * sizeof(TGameData));
	
	for(i=0; i<iN; ++i)
	{
		pN[i].nIndex = rand()%iN;
	}
	
	qsort(pN, iN, sizeof(TGameData), (int (*)(const void*, const void*))(TGameData::Less));
	
	for(i=0; i< iN; ++i)
		printf("%3d: %4d\n", i, pN[i].nIndex);
}


