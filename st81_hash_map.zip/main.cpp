
#pragma warning( disable : 4786)

#include <hash_map>
#include <string>
#include <stdio.h>


using namespace std;
using namespace stdext;

// �˻��� Ű(Key)�� ����� ����ü
struct MyStruct
{
	int nID;
	int iValue;
	
	MyStruct(){}
	MyStruct(int _id, int _value)
	{
		nID =_id;
		iValue= _value;
	}

	operator size_t() const
	{
		return sizeof(MyStruct);
	}
};


// �� ���꿡 ���� �Լ���
template<class T>
struct Tgreater
{
	bool operator()(const T& t1, const T& t2) const
	{
		return (t1.nID < t2.nID);
	}
};

typedef hash_map< MyStruct										\
				, string										\
				, hash_compare <MyStruct, Tgreater<MyStruct> >	\
				>	mpLst;

typedef mpLst::iterator		itLst;

typedef std::pair <MyStruct, string> MyPair;


void main()
{
	mpLst	hsh_map;
	itLst	it;
	
	MyStruct st = MyStruct( 300,  3000);
	
	hsh_map.insert(	MyPair( st, "2nd"));
	hsh_map[MyStruct( 600,  6000)];



	for(it = hsh_map.begin(); it != hsh_map.end(); ++it)
	{
		printf("%d	", (*it).first.nID);
		printf("%d	", (*it).first.iValue);
		printf("%s\n", (*it).second.c_str());
	}
}