
#pragma warning( disable : 4786)

#include <string>
#include <vector>

#include <stdio.h>


typedef std::vector<std::string >	lsStr;
typedef lsStr::iterator			itStr;


void LcUtil_StrList(lsStr& vStr, char* sIn, char* sSpes=NULL)
{
	static char sp[]   = " ,\t/\'\"\\\n";
	char *token = NULL;

	if(!strlen(sIn))
		return;

	if(!sSpes)
		sSpes = sp;

	token = strtok( sIn, sSpes );

	if(!token || !strlen(token))
		return;

	vStr.push_back(token);

	while( token != NULL )
	{
		token = strtok( NULL, sSpes );

		if(token && strlen(token))
			vStr.push_back(token);
	}
}


void main()
{
	char sIn[] = "A string\tof ,,tokens\nand some/more tokens\"needs";
	char seps[]   = " ,\t\n";

	lsStr		vStr;


	LcUtil_StrList(vStr, sIn);

	for(int i=0; i<vStr.size(); ++i)
	{
		char s[128];
		
		strcpy(s, vStr[i].c_str());

		printf("%s\n", s);
	}
}