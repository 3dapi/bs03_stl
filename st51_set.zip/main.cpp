

#pragma warning( disable : 4786)

#include <set>

#include <stdio.h>


struct Tinf
{
	int	wId;

	Tinf(){}
	Tinf(int c) : wId(c){}
};

template<class T>
struct TsrtG
{
	bool operator()(const T& t1,const T& t2) const	{ return t1.wId < t2.wId; }
};


typedef std::set<Tinf, TsrtG<Tinf> >	stInt;
typedef stInt::iterator			itInt;





void main()
{
	stInt lsInt;

	for(int i=0; i<100; ++i)
	{
		lsInt.insert(Tinf( rand()%8));
	}


	for(itInt it= lsInt.begin(); it !=lsInt.end(); )
	{
		Tinf infc = (*it);
		printf("%d\n", infc.wId);
		++it;
	}
}