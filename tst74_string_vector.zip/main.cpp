
#pragma warning(disable: 4786)

#include <vector>
#include <string>

#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>
#include <stdio.h>
#include <time.h>

typedef std::vector<std::string>	lsStr;

char* LcUtil_SimpleStrDateTime(char* sYear, char* sMon, char* sDay, char* sTime, time_t lTime);

void LcUtil_GetAllFiles(lsStr* pOut, char* sPath);
void LcUtil_GetAllFolders(lsStr* pOut, char* sPath);


void main()
{
	lsStr	vStr;

	LcUtil_GetAllFiles(&vStr, "C:/Program Files");

	int iSize = vStr.size();

	for(int i=0; i<iSize; ++i)
		printf("%4d %s\n", i+1, vStr[i].c_str());

	vStr.clear();


	LcUtil_GetAllFolders(&vStr, "C:/Program Files");

	iSize = vStr.size();

	for(i=0; i<iSize; ++i)
		printf("%4d %s\n", i+1, vStr[i].c_str());

	vStr.clear();
}



void LcUtil_GetAllFiles(lsStr* pOut, char* sPath)
{
	char sSearchPath[2048];
	_finddata_t fd;
	long handle;

	int result=1;

	sprintf(sSearchPath,"%s/*.*", sPath);
	handle=_findfirst(sSearchPath,&fd);

	if (handle == -1)
		return;

	while (result != -1)
	{
		char sDate[128];
		char sYear[32];
		char sMon[32];
		char sDay[32];
		char sTime[32];

		if( (fd.attrib & 0x20) && (fd.name[0] !='.'))
		{
			char sT[4096];
			strcpy(sDate, LcUtil_SimpleStrDateTime(sYear, sMon, sDay, sTime, fd.time_write ) );
			sprintf(sT, "F %s %s %s %s  %10d %s %s", sYear, sMon, sDay, sTime, fd.size, sPath, fd.name);
			pOut->push_back(sT);
		}

		result=_findnext(handle,&fd);

	}

	_findclose(handle);

}


void LcUtil_GetAllFolders(lsStr* pOut, char* sPath)
{
	char sSearchPath[2048];
	_finddata_t fd;
	long handle;

	int result=1;

	sprintf(sSearchPath,"%s/*.*", sPath);
	handle=_findfirst(sSearchPath,&fd);

	if (handle == -1)
		return;

	while (result != -1)
	{
		char sDate[128];
		char sYear[32];
		char sMon[32];
		char sDay[32];
		char sTime[32];

		if( (fd.attrib & 0x10) && (fd.name[0] !='.'))
		{
			char sT[4096];
			strcpy(sDate, LcUtil_SimpleStrDateTime(sYear, sMon, sDay, sTime, fd.time_write ) );
			sprintf(sT, "D %s %s %s %s  %10d %s %s", sYear, sMon, sDay, sTime, fd.size, sPath, fd.name);
			pOut->push_back(sT);
		}

		result=_findnext(handle,&fd);

	}

	_findclose(handle);

}








char* LcUtil_SimpleStrDateTime(char* sYear, char* sMon, char* sDay, char* sTime, time_t lTime)
{
	static char sTimeA[256];

	char C[64];
	char Y[16];
	char M[16];
	char D[16];
	char T[32];

	memset(sTimeA, 0, sizeof sTimeA);

	strcpy(C, ctime( &lTime ) );
	sscanf(C, "%*s %*s %*s %s", T);
	sscanf(C, "%*s %*s %*s %*s %s", Y);
	sscanf(C, "%*s %s", M);
	sscanf(C, "%*s %*s %s", D);

	T[5]=0;

	if(		0==_strnicmp(M, "Jan", 3))
		strcpy(M, "01");

	else if(0==_strnicmp(M, "Feb", 3))
		strcpy(M, "02");

	else if(0==_strnicmp(M, "Mar", 3))
		strcpy(M, "03");

	else if(0==_strnicmp(M, "Apr", 3))
		strcpy(M, "04");

	else if(0==_strnicmp(M, "May", 3))
		strcpy(M, "05");

	else if(0==_strnicmp(M, "Jun", 3))
		strcpy(M, "06");

	else if(0==_strnicmp(M, "Jul", 3))
		strcpy(M, "07");

	else if(0==_strnicmp(M, "Aug", 3))
		strcpy(M, "08");

	else if(0==_strnicmp(M, "Sep", 3))
		strcpy(M, "09");

	else if(0==_strnicmp(M, "Oct", 3))
		strcpy(M, "10");

	else if(0==_strnicmp(M, "Nov", 3))
		strcpy(M, "11");

	else if(0==_strnicmp(M, "Dec", 3))
		strcpy(M, "12");

	sprintf(sTimeA, "%s %s %s %s", Y, M, D, T);

	if(sYear)
		strcpy(sYear, Y);

	if(sMon)
		strcpy(sMon, M);

	if(sDay)
		strcpy(sDay, D);

	if(sTime)
		strcpy(sTime, T);

	return sTimeA;
}