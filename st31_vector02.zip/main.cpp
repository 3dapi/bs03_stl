

#include <vector>
#include <stdio.h>


struct GameData
{
	int nIdx;
	int data;
	
	GameData(int _nIdx, int _data)
	{
		nIdx= _nIdx;
		data = _data;
	}
};

void main()
{
	int i;
	
	std::vector< GameData >	vGameData;
	
	printf("vGameData Size: %d\n\n", vGameData.size());
	
	for(i=0; i< 10; ++i)
	{
		vGameData.push_back( GameData(i, i*100) );
	}
	
	printf("vGameData Size: %d\n\n", vGameData.size());
	
	if(!vGameData.empty())
	{
		int iSize = vGameData.size();

		for(i=0; i<iSize; ++i)
		{
			printf("%d  %d\n", vGameData[i].nIdx, vGameData[i].data);
		}
	}
	
	vGameData.clear();
}
