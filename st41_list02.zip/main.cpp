
#pragma warning( disable : 4786)

#include <list>
#include <string>

#include <stdio.h>


int main()
{
	std::list<std::string>				vList;
	std::list<std::string>::iterator	it;
	
	vList.push_back("3rd");
	vList.push_back("4th");
	vList.push_front("2nd");
	vList.push_front("1st");
	
	printf("List in list......\n");

	for(it=vList.begin(); it!=vList.end();)
	{
		std::string str;
		str=*it;
		printf("%s\n", str.c_str());
		++it;
	}

	printf("\nfront() and back()......\n");
	// front
	printf("%s\n", vList.front().c_str());
	// back
	printf("%s\n", vList.back().c_str());


	printf("\nAfter pop_front() and pop_back()......\n");
	vList.pop_front();
	vList.pop_back();

	for(it=vList.begin(); it!=vList.end();)
	{
		std::string str;
		str=*it;
		printf("%s\n", str.c_str());
		++it;
	}
	

	printf("\nAfter insert()......\n");
	
	std::string sStr[] ={ "Hello ", "world!!! ", "welcome ", "stl world\n\n"};

	vList.insert(vList.begin(), &sStr[0], &sStr[4]);

	for(it=vList.begin(); it!=vList.end();)
	{
		std::string str;
		str=*it;
		printf("%s", str.c_str());
		++it;
	}
	return 0;
}