
#pragma warning( disable : 4786)

#include <list>
#include <string> 
#include <functional>

#include <stdio.h>


template<class T>
struct StringUpper : public std::greater<T>
{
	bool operator()(const T& v1, const T& v2)
	{
		if( _stricmp( v1.c_str(), v2.c_str()) >=0)
			return false;

		return true;
	}
};


typedef std::list<std::string>	ltStr;
typedef ltStr::iterator			itStr;



void main() 
{ 
	ltStr vFolder1;

	vFolder1.push_back("Bsfsdsd 1"); 
	vFolder1.push_back("dfdfdSfftring 3"); 
	vFolder1.push_back("Zassdsfdffasdfgh 2"); 
	vFolder1.push_back("Yfsg 4"); 
	vFolder1.push_back("dsfsdfasdf 8"); 
	vFolder1.push_back("W652564fgdf 5"); 
	vFolder1.push_back("56765a 6"); 
	vFolder1.push_back("hjkhjfS 7"); 
	
	vFolder1.sort( StringUpper<std::string>() );
	
	itStr	_F = vFolder1.begin();
	itStr	_L = vFolder1.end();

	for(; _F != _L; ++_F ) 
	{ 
		printf("Name: %s\n", (*_F).c_str()); 
	} 
}
