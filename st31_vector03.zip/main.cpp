#include <vector>
#include <stdio.h>


struct GameData
{
	int nIdx;
	int data;
	
	GameData(int _nIdx, int _data)
	{
		nIdx= _nIdx;
		data = _data;
	}
};

void main()
{
	int i;
	
	std::vector< GameData* >	pvData;
	
	for(i=0; i< 10; ++i)
		pvData.push_back( new GameData(i, i*100) );

	
	int iSize = pvData.size();
	for(i=0; i< iSize; ++i)
	{
		std::vector< GameData* >::reference it = pvData[i];
		
		printf("Iterator:%d  %d	", it->nIdx, it->data);

		GameData* p = pvData[i];
		printf("Pointer:%d  %d\n", p->nIdx, p->data);
	}
	

	for(i=0; i< iSize; ++i)
		delete pvData[i];

	
	pvData.clear();
}
