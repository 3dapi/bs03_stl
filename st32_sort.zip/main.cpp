

#include <algorithm>

#include <stdio.h>
#include <malloc.h>


struct TGameData
{
	int nIndex;

	static bool Greater(const TGameData& v1, const TGameData& v2) 
	{
		return !Less(v1, v2);
	}

	static int Less( const TGameData& v1, const TGameData& v2)
	{
		return v1.nIndex < v2.nIndex;
	}
};


void main()
{
	int			i;
	const int	iN=200;
	
	TGameData*	pN = (TGameData*) malloc( iN * sizeof(TGameData));
	
	for(i=0; i<iN; ++i)
		pN[i].nIndex = rand()%iN;
	

	std::sort(pN, pN+iN, TGameData::Greater);
	
	for(i=0; i< iN; ++i)
		printf("%3d: %4d\n", i, pN[i].nIndex);

	
	free(pN);
}
