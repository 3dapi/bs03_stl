
#include <vector>
#include <algorithm>
#include <functional>

#include <stdio.h>


struct GameObject
{
	int		nId;
	float	fR;			// �Ÿ�

	GameObject()
		:	nId	(0xFFFFFFFF)
		,	fR	(0)
	{
	}
};

typedef std::vector<GameObject*>	lsObject;
typedef lsObject::iterator			itObject;

template<class T>
struct SortGp
{
	bool operator()(const T& p1, const T& p2) const
	{ 
		return ( p1->fR > p2->fR);
	}
};



void main()
{
	int		i;
	
	lsObject	vObject;
	
	for(i=0; i<200; ++i)
	{
		GameObject*	pObj = new GameObject;
		
		pObj->nId = i;
		pObj->fR = float(rand()%200);
		
		vObject.push_back(pObj);
	}
	
	
	printf ("\n----------------Before Sorting----------------\n\n");
	
	int iSize = vObject.size();

	for(i=0;i<iSize; ++i)
	{
		GameObject* pObj = vObject[i];
		printf(" Id: %3d Distance: %3.f\n", pObj->nId, pObj->fR);
	}
	
	std::sort(vObject.begin(), vObject.end(), SortGp<GameObject*>());
	
	printf ("\n----------------After Sorting------------------\n\n");
	

	itObject	_F	= vObject.begin();
	itObject	_L	= vObject.end();

	for(;_F != _L; ++_F)
	{
		printf(" Id: %3d Distance: %3.f\n", (*_F)->nId, (*_F)->fR);
	}

	_F	= vObject.begin();
		
	for(;_F != _L; ++_F)
	{
		delete (*_F);
	}
	
	
	vObject.clear();
}
