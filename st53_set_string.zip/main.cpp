#pragma warning( disable : 4786)


#include <set>
#include <string>

#include <stdio.h>


struct TsrtStrG																	// For sort... descendent Sort
{
	bool operator()(const std::string& t1,const std::string& t2) const
	{
		if(_stricmp(t1.c_str(), t2.c_str()) <0)
			return true;
		
		return false;
	}
};


typedef std::set<std::string, TsrtStrG >	stStr;
typedef stStr::iterator						itStr;



void main()
{
	stStr vStr;
	
	vStr.insert("Efg");
	vStr.insert("Efg");
	vStr.insert("abc");
	vStr.insert("Abc");
	vStr.insert("Kbddef");
	vStr.insert("Kbddefg");
	vStr.insert("kbddefg");
	vStr.insert("Efg");
	vStr.insert("Kbddef");
	vStr.insert("Kbddefg");
	
	for(itStr it= vStr.begin(); it !=vStr.end(); )
	{
		std::string infc = (*it);
		printf("%s\n", infc.c_str());
		++it;
	}
}