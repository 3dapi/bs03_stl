
#include <vector>
#include <algorithm>

#include <stdio.h>
#include <Windows.h>


template<class T> inline
bool T_IsNotAllocated(T* &t)
{
	return (!&t || !t || IsBadReadPtr(t, sizeof(T)) );	
}

template<class T> inline
bool T_IsAllocated(T* &t)
{
	return !T_IsNotAllocated(t);
}



// For Find
template<class T>
struct McFind
{
public:
	T* c;
	
	McFind(T* &_c)
	{
		c=_c;
	}
	bool operator()(T* &t) const
	{
		return (c->nId == t->nId);
	}
	
};


template<class T1, class T2> inline
T2* T_Find_If(T1 t1, T2* &t2)
{
	T2 ** t;
	
	t = NULL;
	t = find_if(t1.begin(), t1.end(), McFind<T2>(t2));
	
	if(t ==t1.end())
		return NULL;
	
	else 
		return (*t);
}


template<class T> inline
void* T_Find_Id(T _F, T _L, int nId)
{
	for (; _F != _L; ++_F)
	{
		if (nId  == (*_F)->nId)
			break;
	}
	
	return ((void*)*(_F));
}


struct GameObject
{
	int	nId;
	float	fR;			// �Ÿ�

	GameObject()
		: nId	(0xFFFFFFFF)
		, fR	(0)
	{
	}
};

typedef std::vector<GameObject*>	lsObject;
typedef lsObject::iterator		itObject;

template<class T>
struct SortGp
{
	bool operator()(const T& p1, const T& p2) const
	{ 
		return ( p1->fR > p2->fR);
	}
};



void main()
{
	int		i;
	
	lsObject	vGameObject;

	for(i=0; i<20; ++i)
	{
		GameObject*	pObj = new GameObject;

		pObj->nId = i;
		pObj->fR = 10 * float(rand()%5000);

		vGameObject.push_back(pObj);
	}
	

	for(i=0;i<vGameObject.size(); ++i)
		printf("%3d:  Distance: %7.f	Id: %3d\n", i, vGameObject[i]->fR, vGameObject[i]->nId);


	std::sort(vGameObject.begin(), vGameObject.end(), SortGp<GameObject*>());

	
	for(i=0; i<25; ++i)
	{
		int	nId = i;
		GameObject*	p =	NULL;
		
		p= (GameObject*)T_Find_Id(vGameObject.begin(), vGameObject.end(), nId);

		if(T_IsAllocated(p))
			printf("Id: %4u	Distance: %7.f\n", (p)->nId, (p)->fR);
		else
			printf("Cannot find nId: %u.\n", nId);
	}

	
	for(i=0;i<vGameObject.size(); ++i)
	{
		if(vGameObject[i])
		{
			delete vGameObject[i];
			vGameObject[i] = NULL;
		}
	}

	vGameObject.clear();
}

